const fs = require("fs")

global.owner = ["628155915536"]
global.idcennel = ''
global.thumb = ''


//Create Panel
global.domain = 'https://rensstore.tokopanellku.my.id'
global.apikey = 'ptla_nuXHQuNNMtHtWknXgX1pvSMzZJbDB53TyGbGpi11Sag'
global.capikey = 'ptlc_JlTYKlwSxIU3Xu7MP4RJUjOm2He8PgddzNQDgJywMcX'
global.eggsnya = '15'
global.location = '1'


global.mess = {
    success: '🤗 Selesai! Semuanya Berjalan Lancar~',
    admin: '_*❗ Perintah Ini Hanya Dapat Digunakan Oleh Admin Grup!*_',
    botAdmin: '_*❗ Bot Harus Menjadi Admin Grup Untuk Menggunakan Perintah Ini!*_',
    owner: '_*❗ Perintah Ini Khusus Untuk Pemilik Bot!*_',
    group: '_*❗ Perintah Ini Hanya Berlaku di Obrolan Grup!*_',
    private: '_*❗ Perintah Ini Hanya Dapat Digunakan di Obrolan Pribadi!*_',
    wait: '_*⏳ Mohon Tunggu, Sedang Dalam Proses!*_',
}

let file = require.resolve(__filename);
fs.watchFile(file, () => {
fs.unwatchFile(file);
console.log(`Update ${__filename}`);
delete require.cache[file];
require(file);
});


//base yoshx
//recode Rafael
//recode Lunatic Cultist