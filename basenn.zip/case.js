require("./config.js")
const fs = require("fs")
const axios = require("axios")
const { exec, spawn, execSync } = require("child_process")
const fetch = require("node-fetch")
const thumb = fs.readFileSync("./thumb.png")
const moment = require('moment-timezone')
const {
getGroupAdmins,
jsonformat,
generateProfilePicture,
getBuffer,
fetchJson
} = require("./lib/myfunc")

const {
   default: makeWASocket,
   BufferJSON,
   WAMessageStubType,
   WA_DEFAULT_EPHEMERAL,
   generateWAMessageFromContent,
   downloadContentFromMessage,
   downloadHistory,
   useMultiFileAuthState,
   proto,
   getMessage,
   InteractiveMessage,
   generateWAMessageContent,
   prepareWAMessageMedia,
   generateWAMessage,
   areJidsSameUser,
   makeInMemoryStore,
   delay
} = require('@whiskeysockets/baileys')

module.exports = async (gease, m) => {
try {
const body = (
(m.mtype === 'conversation' && m.message.conversation) ||
(m.mtype === 'imageMessage' && m.message.imageMessage.caption) ||
(m.mtype === 'documentMessage' && m.message.documentMessage.caption) ||
(m.mtype === 'videoMessage' && m.message.videoMessage.caption) ||
(m.mtype === 'extendedTextMessage' && m.message.extendedTextMessage.text) ||
(m.mtype === 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ||
(m.mtype === 'templateButtonReplyMessage' && m.message.templateButtonReplyMessage.selectedId)
) ? (
(m.mtype === 'conversation' && m.message.conversation) ||
(m.mtype === 'imageMessage' && m.message.imageMessage.caption) ||
(m.mtype === 'documentMessage' && m.message.documentMessage.caption) ||
(m.mtype === 'videoMessage' && m.message.videoMessage.caption) ||
(m.mtype === 'extendedTextMessage' && m.message.extendedTextMessage.text) ||
(m.mtype === 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ||
(m.mtype === 'templateButtonReplyMessage' && m.message.templateButtonReplyMessage.selectedId)
) : '';

async function downloadMp3(url) {
try {
// jalur sampah
let mp3File = './.npm/'+getRandom('.mp3')
ytdl(url, {filter: 'audioonly'}).pipe(fs.createWriteStream(mp3File)).on('finish', async() => {
await gease.sendMessage(from, {audio: fs.readFileSync(mp3File), mimetype: 'audio/mpeg'}, {quoted:m})
fs.unlinkSync(mp3File)
})
} catch(e) {
console.log(e)
return gease.sendteks(from, util.format(e), m)
}
}

const budy = (typeof m.text === 'string') ? m.text : '';
const botNumber = await gease.decodeJid(gease.user.id)
const isCreator = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const _prem = require("./lib/premium");
const premium = JSON.parse(fs.readFileSync('./database/premium.json'));
const isPremium = isCreator ? true : _prem.checkPremiumUser(m.sender, premium)
const from = m.key.remoteJid
const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
const isCmd = body.startsWith(prefix)
const isCommand = isCmd ? body.slice(1).trim().split(' ').shift().toLowerCase() : ""
const command = isCreator ? body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() : isCommand
const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const sender = m.key.fromMe ? (gease.user.id.split(':')[0]+'@s.whatsapp.net' || gease.user.id) : (m.key.participant || m.key.remoteJid)
const senderNumber = sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const fatkuns = (m.quoted || m)
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.m || quoted).mimetype || ''
const qmsg = (quoted.m || quoted)

const groupMetadata = m.isGroup ? await gease.groupMetadata(m.chat).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const groupOwner = m.isGroup ? groupMetadata.owner : ''
const isGroupOwner = m.isGroup ? (groupOwner ? groupOwner : groupAdmins).includes(m.sender) : false

//Ucapan Waktu
const xtime = moment.tz('Asia/Kolkata').format('HH:mm:ss')
const xdate = moment.tz('Asia/Kolkata').format('DD/MM/YYYY')
const time2 = moment().tz('Asia/Kolkata').format('HH:mm:ss')

if (time2 < "23:59:00") {
  var ucapanWaktu = `Selamat Malam 🌌`
}
if (time2 < "19:00:00") {
  var ucapanWaktu = `Selamat Sore 🌃`
}
if (time2 < "18:00:00") {
  var ucapanWaktu = `Selamat Sore 🌃`
}
if (time2 < "15:00:00") {
  var ucapanWaktu = `Selamat Siang 🌅`
}
if (time2 < "11:00:00") {
  var ucapanWaktu = `Selamat Pagi 🌄`
}
if (time2 < "05:00:00") {
  var ucapanWaktu = `Selamat Pagi 🌄`
}


//Function Reply
const ments = (teks) => {return teks.match('@') ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : [sender]}
const reply = (teks) => {return gease.sendMessage(m.chat, { text: teks, mentions: ments(teks) }, {quoted: m})}
const fcall = {
    key: {
        fromMe: false,
        participant: '0@s.whatsapp.net',
        ...(from ? { remoteJid: 'status@broadcast' } : {})
    },
    message: {
        extendedTextMessage: {
            text: `*${global.botname} • ${global.creator}*`
        }
    }
};

const fdoc = {
    key: {
        participant: '0@s.whatsapp.net',
        ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
    },
    message: {
        documentMessage: {
            title: `*${global.botname}*`,
            jpegThumbnail: thumb
        }
    }
};

const fdocerror = {
    key: {
        participant: '0@s.whatsapp.net',
        ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
    },
    message: {
        documentMessage: {
            title: `*Penggunaan Salah!*`,
            jpegThumbnail: thumb
        }
    }
};

const fvn = {
    key: {
        participant: '0@s.whatsapp.net',
        ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
    },
    message: {
        audioMessage: {
            mimetype: 'audio/ogg; codecs=opus',
            seconds: 359996400,
            ptt: 'true'
        }
    }
};

const fgif = {
    key: {
        participant: '0@s.whatsapp.net',
        ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
    },
    message: {
        videoMessage: {
            title: global.botname,
            h: 'h',
            seconds: 359996400,
            gifPlayback: 'true',
            caption: `*${global.creator}*`,
            jpegThumbnail: thumb
        }
    }
};

const ftroli = {
    key: {
        fromMe: false,
        participant: '0@s.whatsapp.net',
        remoteJid: 'status@broadcast'
    },
    message: {
        orderMessage: {
            itemCount: 2024,
            status: 200,
            thumbnail: thumb,
            surface: 200,
            message: `${global.botname} • ${global.creator}`,
            orderTitle: 'ordertitle',
            sellerJid: '0@s.whatsapp.net'
        }
    },
    contextInfo: {
        forwardingScore: 999,
        isForwarded: true
    },
    sendEphemeral: true
};


if (isCmd) console.log("~>Command", text, "from", pushname, "in", m.isGroup ? "Group Chat" : "Private Chat", '[' + args.length + ']');

const getShortenedUrl = async (url) => {
let { data } = await axios.post("https://shorturl.ptz.fund", { url });
return data.data.shortUrl;
};

let list = [];

for (let i of owner) {
    const displayName = await gease.getName(i);
    const vcard = `
BEGIN:VCARD
VERSION:3.0
N:${displayName}
FN:${await gease.getName(i)}
item1.TEL;waid=${i}:${i}
item1.X-ABLabel:Click here to chat
item2.EMAIL;type=INTERNET:lunatic.acc@gmail.com
item2.X-ABLabel:YouTube
item3.URL:https://google.com
item3.X-ABLabel:GitHub
item4.ADR:;;Indonesia;;;;
item4.X-ABLabel:Region
END:VCARD`;

    list.push({
        displayName,
        vcard
    });
}


function addUser(id, name, number, limit, date_reg, status) {
    const databasePath = './database/data-user.json';
    const users = JSON.parse(fs.readFileSync(databasePath, 'utf8'));
    const newUser = { id, name, number, limit, date_reg, status };
    users.push(newUser);
    fs.writeFileSync(databasePath, JSON.stringify(users, null, 2), 'utf8');
}

function checkUser(number) {
    const databasePath = './database/data-user.json';
    const users = JSON.parse(fs.readFileSync(databasePath, 'utf8'));

    // Cek apakah nomor telepon sudah terdaftar
    const userExists = users.some(user => user.number === number);
    return userExists;
}

function loadUser(number) {
    const databasePath = './database/data-user.json';
    const users = JSON.parse(fs.readFileSync(databasePath, 'utf8'));

    // Cari user berdasarkan nomor telepon
    const user = users.find(user => user.number === number);
    return user;
}

function checkTextValidity(text) {
    // Regular expression to match alphanumeric characters only
    const alphanumericRegex = /^[a-zA-Z0-9\s]{1,15}$/;

    // Test if the text matches the alphanumeric pattern and length
    return alphanumericRegex.test(text);
}

const generateUniqueId = (length = 10) => {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const databasePath = './database/data-user.json';
    const users = JSON.parse(fs.readFileSync(databasePath, 'utf8'));
    let result;

    const checkUserId = id => users.some(user => user.id === id);

    do {
        result = Array.from({ length }, () => characters.charAt(Math.floor(Math.random() * characters.length))).join('');
    } while (checkUserId(result));

    return result;
};

function senderr(textinf, body, title) {
    gease.sendMessage(m.chat, {
        text: textinf,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            mentionedJid: [sender],
            externalAdReply: {
                showAdAttribution: true,
                title: title,
                body: body,
                thumbnailUrl: "https://telegra.ph/file/a3d6e9d4b0d8d00a8d482.png",
                sourceUrl: "",
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocerror });
}

function responbot(textf, usern) {
    gease.sendMessage(m.chat, {
        text: textf,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            mentionedJid: [sender],
            externalAdReply: {
                showAdAttribution: true,
                title: ucapanWaktu,
                body: `G-Ease Bot - Whatsapp Bot`,
                thumbnailUrl: "https://telegra.ph/file/a4412af201971bf7c505e.jpg",
                sourceUrl: "",
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fdocerror });
}

function registeryet() {
senderr(`Tolong Registrasi terlebih dahulu agar bisa menggunakan ${botname}\nKetik .daftar <nama>`, `Please register first`, `Not Registered yet!`);
}

function runtime(seconds) {
	seconds = Number(seconds);
	var d = Math.floor(seconds / (3600 * 24));
	var h = Math.floor(seconds % (3600 * 24) / 3600);
	var m = Math.floor(seconds % 3600 / 60);
	var s = Math.floor(seconds % 60);
	var dDisplay = d > 0 ? d + (d == 1 ? " Hari, " : " Hari, ") : "";
	var hDisplay = h > 0 ? h + (h == 1 ? " Jam, " : " Jam, ") : "";
	var mDisplay = m > 0 ? m + (m == 1 ? " Menit, " : " Menit, ") : "";
	var sDisplay = s > 0 ? s + (s == 1 ? " Detik" : " Detik") : "";
	return dDisplay + hDisplay + mDisplay + sDisplay;
}

function totalfitur() {
            var mytext = fs.readFileSync("./case.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length
            return numUpper
        }

switch (command) {

case "fcall": {
gease.sendMessage(m.chat, {text: `Fcall`}, {quoted: fcall})
}
break
case "fdoc": {
gease.sendMessage(m.chat, {text: `Fdoc`}, {quoted: fdoc})
}
break
case "fvn": {
gease.sendMessage(m.chat, {text: `Fvn`}, {quoted: fvn})
}
break
case "fgif": {
gease.sendMessage(m.chat, {text: `Fgif`}, {quoted: fgif})
}
break
case "ftroli": {
gease.sendMessage(m.chat, {text: `Ftroli`}, {quoted: ftroli})
}
break

case "menu": {
if (!checkUser(sender)) return registeryet()
const datausr = loadUser(sender)
const mtext = `
*╭╼╾⌯ \`「 𝗕𝗢𝗧  𝗜𝗡𝗙𝗢 」\`*
*│*
*│ ➠ Name  : ${global.botname}*
*│ ➠ Owner  : ${global.creator}*
*│ ➠ Version  : ${global.botversion}*
*│ ➠ Type Sc  : ᴄᴀꜱᴇ*
*│ ➠ Runtime  :*
*│     ➥ ${runtime(process.uptime())}*
*│ ➠ Mode : ᴘᴜʙʟɪᴄ*
*│ ➠ Total Fitur : ${totalfitur()} ꜰɪᴛᴜʀ*
*│*
*╰╼╾╼╾╼╾⊸*
͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏
*╭╼╾⌯ \`「 𝗨𝗦𝗘𝗥 𝗜𝗡𝗙𝗢 」\`*
*│*
*│ ➥ Name  : ${datausr.name}*
*│ ➥ Number  : ${(datausr.number).replace(/@s\.whatsapp\.net$/, '')}*
*│ ➥ Status  : ${datausr.status}*
*│ ➥ Limit  : ${datausr.limit}*
*│*
*╰╼╾╼╾╼╾⊸*


*≺───» 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 «───≻*

*_⌲ Jika Menemukan Bug/Error Tolong Segera Lapor Ke Owner_*
*_⌲ Owner : Ketik .owner_*

*≺──────────────────≻*


*╭╼╾⌥ \`⌠ 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨 ⌡\`*
*│*
*│* ✦ .owner
*│* ✦ .register
*│* ✦ .profil
*│* ✦ .limit
*│*
*╰╼╾╼╾╼╾⌾*

*╭╼╾⌥ \`⌠ 𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨 ⌡\`*
*│*
*│* ✦ .self
*│* ✦ .public
*│* ✦ .block
*│* ✦ .unblock
*│* ✦ .addprem
*│* ✦ .delprem
*│* ✦ .listprem
*│*
*╰╼╾╼╾╼╾⌾*

*╭╼╾⌥ \`⌠ 𝗚𝗥𝗢𝗨𝗣 𝗠𝗘𝗡𝗨 ⌡\`*
*│*
*│* ✦ .welcome
*│* ✦ .setwelcome
*│* ✦ .kick
*│* ✦ .add
*│* ✦ .hidetag
*│* ✦ .group
*│* ✦ .editsubject
*│* ✦ .editdesk
*│* ✦ .setppgc
*│*
*╰╼╾╼╾╼╾⌾*

*╭╼╾⌥ \`⌠ 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 𝗠𝗘𝗡𝗨 ⌡\`*
*│*
*│* ✦ .tiktok
*│* ✦ .youtube
*│* ✦ .instagram
*│* ✦ .pinterest
*│* ✦ .ytsearch
*│* ✦ .play
*│* ✦ .toimage
*│* ✦ .tomp4
*│* ✦ .tomp3
*│* ✦ .tourl
*│* ✦ .tovn
*│*
*╰╼╾╼╾╼╾⌾*

*╭╼╾⌥ \`⌠ 𝗙𝗨𝗡 𝗠𝗘𝗡𝗨 ⌡\`*
*│*
*│* ✦ .afk
*│* ✦ .sticker
*│* ✦ .smeme
*│* ✦ .darkjokes
*│* ✦ .quotes
*│* ✦ .jalantikus
*│*
*╰╼╾╼╾╼╾⌾*

*╭╼╾⌥ \`⌠ 𝗚𝗔𝗠𝗘 𝗠𝗘𝗡𝗨 ⌡\`*
*│*
*│* ✦ .ttc
*│* ✦ .delttc
*│* ✦ .suitpvp
*│*
*╰╼╾╼╾╼╾⌾*
`

async function sendMessages() {
   await gease.sendMessage(m.chat, {
      video: { url: "https://telegra.ph/file/635b5fe20b04636fef435.mp4" },
      caption: mtext,
      gifPlayback: true,
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        mentionedJid: [sender],
        externalAdReply: {
          showAdAttribution: true,
          title: ucapanWaktu,
          body: xdate,
          thumbnailUrl: "https://telegra.ph/file/a4412af201971bf7c505e.jpg",
          sourceUrl: "https://www.whatsapp.com",
          mediaType: 1,
          renderLargerThumbnail: true
        }
        }
    }, { quoted: fcall });

    await gease.sendMessage(m.chat, {
      audio: { url: "https://pomf2.lain.la/f/o41nqtds.mp3" },
      mimetype: 'audio/mp4',
      ptt: true
    }, { quoted: fvn });
  }

  sendMessages();
}
break


case "owner": {
                gease.sendMessage(from, {
                    contacts: {
                        displayName: `${list.length} Contact`,
                        contacts: list
                    }, contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: ucapanWaktu,
                                body: "Contact Owner",
                                thumbnailUrl: "https://telegra.ph/file/a4412af201971bf7c505e.jpg",
                                sourceUrl: "https://www.whatsapp.com",
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                }, {
                    quoted: fdoc
                })
            }
            break





case "register": case "reg": case "daftar": case "verify": {
    const userRegisteredText = (datausr, isNew) => `
*╭╼╾⌯ \`「 ${isNew ? "𝗦𝘂𝗰𝗰𝗲𝘀𝘀 𝗥𝗲𝗴𝗶𝘀𝘁𝗲𝗿𝗲𝗱" : "𝗔𝗹𝗿𝗲𝗮𝗱𝘆 𝗥𝗲𝗴𝗶𝘀𝘁𝗲𝗿𝗲𝗱"} 」\`*
*│*
*│ ➥ Name  : ${datausr.name}*
*│ ➥ Number  : ${(datausr.number).replace(/@s\.whatsapp\.net$/, '')}*
*│ ➥ Status  : ${datausr.status}*
*│ ➥ Limit  : ${datausr.limit}*
*│ ➥ id   : ${datausr.id}*
*│ ➥ Tanggal Registrasi: ${datausr.date_reg}*
*│*
*╰╼╾╼╾╼╾⊸*
`;

    const sendMessage = (datausr, isNew) => {
        gease.sendMessage(m.chat, {
            text: userRegisteredText(datausr, isNew),
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                mentionedJid: [sender],
                externalAdReply: {
                    showAdAttribution: true,
                    title: ucapanWaktu,
                    body: "𝗥𝗲𝗴𝗶𝘀𝘁𝗲𝗿𝗲𝗱",
                    thumbnailUrl: "https://telegra.ph/file/a4412af201971bf7c505e.jpg",
                    sourceUrl: "",
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: fcall });
    };
     const checkName = (name) => {
        const databasePath = './database/data-user.json';
        const users = JSON.parse(fs.readFileSync(databasePath, 'utf8'));
        return users.some(user => user.name.toLowerCase() === name.toLowerCase());
    };

     const checkNames = (name) => /^[a-zA-Z0-9]{1,15}$/.test(name) && JSON.parse(fs.readFileSync('./database/data-user.json', 'utf8')).some(user => user.name.toLowerCase() === name.toLowerCase());


    if (checkUser(sender)) {
        const datausr = loadUser(sender);
        sendMessage(datausr, false);
    } else {
        if (!text) return senderr(`Ketik .${command} <name>`, `Ketik .${command} <name>`, `Penggunaan Salah!`);
        if (checkName(text)) return senderr(`Nama ${text} sudah digunakan user lain\nGunakan nama lain untuk registrasi`, ` `, `Name is Already in use!`);
        if (!checkTextValidity(text)) return senderr(`Nama harus terdiri dari huruf & angka dengan maksimal 15 karakter.`, `Penggunaan Salah!`);
        const id = generateUniqueId()
        addUser(id, text, sender, "100", xdate, "ᴍᴇᴍʙᴇʀ");
        const datausr = loadUser(sender);
        sendMessage(datausr, true);
    }
}
break;

case "profil": case "profile": {
if (!checkUser(sender)) return registeryet()
const datausr = loadUser(sender);
const textprfl = `
*╭╼╾⌯ \`「 𝗨𝗦𝗘𝗥 𝗣𝗥𝗢𝗙𝗜𝗟𝗘 」\`*
*│*
*│ ➥ Name  : ${datausr.name}*
*│ ➥ Number  : ${(datausr.number).replace(/@s\.whatsapp\.net$/, '')}*
*│ ➥ Status  : ${datausr.status}*
*│ ➥ Limit  : ${datausr.limit}*
*│ ➥ id   : ${datausr.id}*
*│ ➥ Tanggal Registrasi: ${datausr.date_reg}*
*│*
*╰╼╾╼╾╼╾⊸*
`

gease.sendMessage(m.chat, {
            text: textprfl,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                mentionedJid: [sender],
                externalAdReply: {
                    showAdAttribution: true,
                    title: ucapanWaktu,
                    body: `Hai @${m.sender.split('@')[0]} - Whatsapp Bot`,
                    thumbnailUrl: "https://telegra.ph/file/a4412af201971bf7c505e.jpg",
                    sourceUrl: "",
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: fcall });

}
break

case "limit": {
if (!checkUser(sender)) return registeryet()
const datausr = loadUser(sender);
const textprfl = `
*╭╼╾⌯ \`「 𝗨𝗦𝗘𝗥 𝗟𝗜𝗠𝗜𝗧 」\`*
*│*
*│ ➥ Name  : ${datausr.name}*
*│ ➥ Status  : ${datausr.status}*
*│ ➥ Limit  : ${datausr.limit}*
*│*
*│ ⎋ Beli/Tambahkan Limit di Shop*
*│ ⎋ Ketik .shop*
*│*
*╰╼╾╼╾╼╾⊸*
`
gease.sendMessage(m.chat, {
            text: textprfl,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                mentionedJid: [sender],
                externalAdReply: {
                    showAdAttribution: true,
                    title: ucapanWaktu,
                    body: `Hai @${m.sender.split('@')[0]} - Whatsapp Bot`,
                    thumbnailUrl: "https://telegra.ph/file/a4412af201971bf7c505e.jpg",
                    sourceUrl: "",
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: fcall });

}
break




case "public": {
if (!isCreator) return responbot(global.mess.owner)
gease.public = true
reply(mess.done)
}

case "private": {
if (!isCreator) return responbot(global.mess.owner)
gease.public = false
reply(mess.done)
}


default:
if (budy.startsWith('~>')) {
if (!isCreator) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return m.reply(bang)
}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))
}
}

if (budy.startsWith('>>')) {
if (!isCreator) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

if (budy.startsWith('$')) {
if (!isCreator) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
}
} catch (err) {
console.log(require('util').format(err));
}
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
fs.unwatchFile(file);
console.log(`Update ${__filename}`);
delete require.cache[file];
require(file);
});
